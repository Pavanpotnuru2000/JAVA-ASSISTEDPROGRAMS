package aceesspecifier;

public class accessspecifier1 {
	public static void main(String[] args){
		System.out.println("default acess specifier");
		defacessspecifier obj = new defacessspecifier();
		obj.display();
		
	}

}
