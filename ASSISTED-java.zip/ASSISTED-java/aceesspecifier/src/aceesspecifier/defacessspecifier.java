package aceesspecifier;

public class defacessspecifier {
	void display() {
		System.out.println("you are using default access specifier");
	}

}

