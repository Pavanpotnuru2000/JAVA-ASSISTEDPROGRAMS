package collections;

import java.util.*;

public class collectionassisted {
	public static void main(String[] args){
		System.out.println("Arraylist");
		ArrayList<String>city=new ArrayList<String>();
		city.add("Bangalore");
		city.add("delhi");
		System.out.println(city);
		
		//creating vector
		System.out.println("\n");
		System.out.println("vector");
		Vector<Integer>vec=new Vector();
		vec.addElement(15);
		vec.addElement(30);
		System.out.println(vec);
		
		//creating linked list
		
		System.out.println("linked list");
		LinkedList<String>names=new LinkedList<String>();
		names.add("alex");
		names.add("john");
		Iterator<String>itr=names.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
			
		
			
			
		//creating hashset
		System.out.println("hashset");
		HashSet<Integer>set=new HashSet<Integer>();
		set.add(101);
		set.add(105);
		set.add(323);
		System.out.println(set);
		
		//linkedhashset
		
		System.out.println("linkedhashset");
		LinkedHashSet<Integer>set2=new LinkedHashSet<Integer>();
		set2.add(11);
		set2.add(13);
		set2.add(18);
		set2.add(10);
		System.out.println(set);
		
		}
	}
	

}
