package parameterized;
class std{
	int id;
	String name;

	std(int i,String n)
	{
	id=i;
	name=n;
	}

	void display() {
	System.out.println(id+" "+name);
	}
}
