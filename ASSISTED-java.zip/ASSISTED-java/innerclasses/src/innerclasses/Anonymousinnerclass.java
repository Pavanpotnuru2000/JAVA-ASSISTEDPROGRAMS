package innerclasses;

abstract class Anonymousinnerclass {
	public abstract void display();
	

}
