package innerclasses;

public class innerclassassisted {
	private String msg="Welcome to java";
	class Inner{
		void hello() {
			System.out.println(msg+",Let us start learning inner classes");
			
		}
		public static void main(String[] args) {
			innerclassassisted obj = new innerclassassisted();
			innerclassassisted.Inner in = obj.new Inner();
			in.hello();
			
			
			  
		}
	}
	
	

}
