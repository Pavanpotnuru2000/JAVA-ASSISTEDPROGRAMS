package innerclasses;

public class innerclassassisted2{
	private String msg="Inner Classes";
	void display() {
		class Inner{
			void msg() {
				System.out.println(msg);
				
			}
		}
	Inner I=new Inner();
	I.msg();
	
	}
	
	public static void main(String[] args) {
		innerclassassisted2 obj2 = new innerclassassisted2();
		obj2.display();
		
		
		
	}
	
}