package innerclasses;

public class innerclassassisted3{
	public static void main(String[] args) {
		Anonymousinnerclass i = new Anonymousinnerclass() {
			public void display() {
				System.out.println("Anonymous Inner Class");
			}
		};
		i.display();
	}
}
