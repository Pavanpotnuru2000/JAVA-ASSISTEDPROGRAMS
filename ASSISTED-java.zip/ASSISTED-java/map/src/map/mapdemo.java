package map;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.TreeMap;

public class mapdemo {
	public static void main(String[] args) {
		HashMap<Integer,String>hm=new HashMap<Integer,String>();
		hm.put(1,"Tim");
		hm.put(2,"Mary");
		hm.put(3,"Catie");
		System.out.println("the elements of hashmap are");
		for(Map.Entry m:hm.entrySet()) {
			System.out.println(m.getKey()+" "+m.getValue());
		
		//hashtable
		Hashtable<Integer,String>ht=new Hashtable<Integer,String>();
		ht.put(4, "Ales");
		ht.put(5, "Rosy");
		ht.put(6, "Alex");
		ht.put(7, "John");
		
		System.out.println("the elements of hashtable");
		for(Map.Entry n:ht.entrySet()){
			System.out.println(n.getKey()+" "+n.getValue());
		}
		
		//treemap
		
		TreeMap<Integer,String>map=new TreeMap<Integer,String>();
		map.put(8, "Annie");
		map.put(9, "Carlotte");
		map.put(10, "Catie");
		
		System.out.println("elements of treemap");
		for(Map.Entry I:map.entrySet()) {
			System.out.println(I.getKey()+""+I.getValue());
		
		
			
		}
		
			
		}
		
	}

}
