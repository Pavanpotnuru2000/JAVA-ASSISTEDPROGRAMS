package methodexecution;

public class overloading {
	public void area(int b, int h) {
		System.out.println("area of triangle:"+(0.5*b*h));
	}
	public void area(int r) {
		System.out.println("area of circle:"+(3.14*r*r));
		
	}
	public static void main(String args[]) {
		overloading obj = new  overloading();
		obj.area(10,12);
		obj.area(7);
	}

}
