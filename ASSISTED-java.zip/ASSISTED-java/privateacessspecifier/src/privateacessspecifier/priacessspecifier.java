package privateacessspecifier;

public class priacessspecifier {
	private void display() {
		System.out.println("you are using private acess specifier");
	}

}
