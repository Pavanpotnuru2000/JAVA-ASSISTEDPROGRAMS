package privateacessspecifier;

public class priacessspecifier1 {
	public void main(String[] args) {
		System.out.println("private access specifier");
		priacessspecifier obj = new priacessspecifier();
		//obj.display();
	}

}
