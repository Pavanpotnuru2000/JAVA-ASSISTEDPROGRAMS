package p1;

public class protectedacesss {
	protected void display() {
		System.out.println("this is protected acess specifier");
	}

}
