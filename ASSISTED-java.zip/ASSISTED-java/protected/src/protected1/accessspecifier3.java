package protected1;
import p1.*;

public class accessspecifier3 extends protectedacesss{
	public static void main(String[] args) {
		accessspecifier3 obj = new accessspecifier3();
		obj.display();
	}
	

}
