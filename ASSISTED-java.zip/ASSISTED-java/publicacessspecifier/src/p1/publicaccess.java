package p1;

public class publicaccess {
	public void display() {
		System.out.println("this is public acess specifier");
	}

}
