package p2;
import p1.*;
public class accessspecifier {
	public static void main(String[] args) {
		publicaccess obj = new publicaccess();
		obj.display();
		
		
	}

}
