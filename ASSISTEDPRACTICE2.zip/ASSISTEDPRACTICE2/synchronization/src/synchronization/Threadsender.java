package synchronization;

class Threadedsender extends Thread 
{ 
    private String msg; 
    private Thread t; 
    Sender  sender; 
    Threadedsender(String m,  Sender obj) 
    { 
        msg = m; 
        sender = obj; 
    } 
  
    public void run() 
    {  
        synchronized(sender) 
        { 
            sender.send(msg); 
        } 
    } 
} 