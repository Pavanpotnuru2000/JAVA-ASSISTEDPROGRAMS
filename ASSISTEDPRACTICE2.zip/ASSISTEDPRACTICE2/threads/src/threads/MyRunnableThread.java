package threads;

public class MyRunnableThread implements Runnable{
	public static int mycount=0;
	public MyRunnableThread() {
		
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(MyRunnableThread.mycount <= 10) {
			try {
				System.out.println("Expl Thread: "+(++MyRunnableThread.mycount));
				Thread.sleep(100);
				
			}catch(InterruptedException iex){
				System.out.println("Exception in Thread:"+iex.getMessage());
				
				
				
			}
		}
	}
	public static void main(String[] args) {
		System.out.println("Starting main thread");
		MyRunnableThread mrt = new MyRunnableThread();
		Thread t = new Thread(mrt);
		t.start();
		while(MyRunnableThread.mycount <= 10) {
			try {
				System.out.println("main thread:"+(++MyRunnableThread.mycount));
				Thread.sleep(100);
				
			}catch(InterruptedException iex) {
				System.out.println("Exception in main thread: "+iex.getMessage());
				
			}
		}
		System.out.println("end of main thread");
	}
	

}
